 <div align="center">

# RazeClicker

**Fast, precise and lightweight auto clicker for Windows.**

Mouse automation, multi-location clicking, keyboard auto clicking and macro recording — all in one application.

[![Downloads](https://img.shields.io/github/downloads/Sorgarso/RazeClicker/total?style=for-the-badge&color=7c6eff)](https://github.com/Sorgarso/RazeClicker/releases)
![Platform](https://img.shields.io/badge/platform-Windows-0078d4?style=for-the-badge)
<img width="890" height="460" alt="RazeClicker" src="https://github.com/user-attachments/assets/259597a1-7c5e-409c-99e4-ad6dc1680f92" />



[**Download Latest Release**](https://github.com/Sorgarso/RazeClicker/releases/latest)

</div>

---

## Features

- **Precise CPS control.** Configure clicking speed in clicks per second, minute, hour or day.
- **Mouse auto clicker.** Supports left and right mouse buttons.
- **Keyboard auto clicker.** Automatically repeat keyboard inputs at a configurable rate.
- **Hold & Toggle modes.** Choose whether clicking continues while holding a hotkey or toggles on and off.
- **Multi-location clicking.** Save screen coordinates and automatically click through multiple locations.
- **Screen position picker.** Select positions directly from your screen.
- **Macro recorder.** Capture mouse and keyboard actions with their original timings and replay them.
- **Configurable playback.** Play macros once or repeat them infinitely.
- **Custom hotkeys.** Configure hotkeys for clicking, recording and macro playback.
- **Always on top.** Keep RazeClicker accessible above other windows.
- **Built-in updater.** Get notified about new releases and update directly from the application.
- **Multilingual interface.** Change the application language in Settings.
- **Windows startup.** Optionally launch RazeClicker when Windows starts.
- **No ads. No telemetry.**

### Clicker

Configure clicking speed, mouse buttons, activation hotkeys and clicking modes.

### Pick Location

Select screen coordinates, manage saved points and enable or disable location-based clicking.

### Recorder

Record mouse and keyboard actions, configure recording and playback hotkeys, and manage saved events.

### Settings

Customize the application language, Windows startup behavior and global hotkeys.

## Getting Started

### Installation

1. Visit the [latest release](https://github.com/Sorgarso/RazeClicker/releases/latest).
2. Download `RazeClicker.exe`.
3. Run the executable.
4. Accept the license agreement.

### Clicker

1. Open the **Clicker** tab.
2. Select Mouse mode or Keyboard mode.
3. Configure the clicking speed and time unit.
4. Select the mouse button if using Mouse mode.
5. Choose your activation hotkey.
6. Select an activation mode:
   - **Hold** — clicking continues while the hotkey is held.
   - **Toggle** — press the hotkey to start or stop clicking.
7. Press the configured hotkey to activate the clicker.

### Pick Location

1. Open the **Pick Location** tab.
2. Enable Pick Location.
3. Press **Pick From Screen** to select a screen position.
4. Add and manage your saved coordinates.
5. The clicker can use your configured locations when location-based clicking is enabled.

### Macro Recorder

1. Open the **Recorder** tab.
2. Use the **Recording** control to start capturing mouse and keyboard actions.
3. Perform the actions you want to record.
4. Use the recording hotkey to control recording.
5. Configure your playback hotkey.
6. Choose a playback repeat mode:
   - **Once** — play the recorded actions once.
   - **Infinite** — continuously repeat the recording.
7. Activate playback using your configured playback hotkey.

The default recording and playback hotkeys are **F5** and **F6**, respectively.

## Settings

RazeClicker provides several customization options:

- **Language** — choose your preferred interface language.
- **Start on Windows** — automatically launch RazeClicker when Windows starts.
- **Hotkeys** — configure global shortcuts for the application's main actions.

## Privacy

RazeClicker does not contain advertisements, analytics or telemetry.

The only network request made by the application is the update check against GitHub.

No personal information or usage statistics are collected.

## Building from Source

RazeClicker is an open-source project written in Rust.

### Requirements

- [Rust](https://www.rust-lang.org/tools/install)
- [Git](https://git-scm.com/)

### Build

Clone the repository:

```bash
git clone https://github.com/Sorgarso/RazeClicker.git
cd RazeClicker
```

Build the optimized release version:

```bash
cargo build --release
```

The compiled executable will be located in:

```text
target/release/
```

## Compatibility

- **Operating System:** Windows
- **Architecture:** See the published release builds.

## Important Notes

- Some games and applications use anti-cheat systems that may block simulated input or prohibit automation tools. Using auto clickers in such environments may result in restrictions or bans.
- Windows security software may occasionally flag the application because it simulates mouse and keyboard input.
- Always download RazeClicker from the official GitHub repository.

Use the application responsibly and at your own risk.

## Contributing

Contributions are welcome!

If you find a bug, have an idea for a new feature or want to improve the project, feel free to open an issue or submit a pull request.

- [Report a Bug](https://github.com/Sorgarso/RazeClicker/issues)
- [Request a Feature](https://github.com/Sorgarso/RazeClicker/issues)
- [View Source Code](https://github.com/Sorgarso/RazeClicker)

## License

RazeClicker is licensed under the [MIT License](LICENSE).

---

<div align="center">

**RazeClicker** — Simple, precise and reliable automation.


</div>
