use crate::ui::fonts::fonts::regular;
use egui::{Color32, FontFamily, FontId, Vec2};
pub fn button(
    ui: &mut egui::Ui,
    colorBg: Color32,
    colorHover: Color32,
    cornerRadius: u8,
    text: &str,
    size: Vec2,
) -> egui::Response {
    let desired = size;
    let (rect, resp) = ui.allocate_exact_size(desired, egui::Sense::click());

    let hovered = resp.contains_pointer();
    let t = ui.ctx().animate_bool_with_time(resp.id, hovered, 0.2);

    let bg = colorBg.lerp_to_gamma(colorHover, t);

    ui.painter().rect_filled(rect, cornerRadius, bg);

    ui.painter().text(
        rect.center(),
        egui::Align2::CENTER_CENTER,
        text,
        regular(14.0),
        Color32::WHITE,
    );

    if hovered {
        ui.ctx().set_cursor_icon(egui::CursorIcon::PointingHand);
    }
    resp
}
